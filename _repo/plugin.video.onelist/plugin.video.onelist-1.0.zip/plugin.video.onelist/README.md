# IPTV Bulgaria
Video plugin for http://www.iptvbulgaria.com/.

Readme for Kodi iptvbulgaria plugin created by zinobg [at] gmail.com

I created this add-on to be able to watch online TV via Kodi on my Raspberry pi3. 
It is tested as well on Kodi for Windows

How to install:

1. Copy the zip file plugin.video.iptvbulgaria.zip to a directory, where Kodi server has access to
	Windows -> <USERDIR>\AppData\Roaming\XBMC\addons\packages\ 
	Linux/OpenElec/LibreElec -> ~/.kodi/addons/packages/
2. Run Kodi and go to System -> Add-ons
3. From Add-ons menu select -> Install from zip file
4. Select the zip file plugin.video.iptvbulgaria.zip
5. IPTV BULGARIA add-on will appear in the list of video add-on
