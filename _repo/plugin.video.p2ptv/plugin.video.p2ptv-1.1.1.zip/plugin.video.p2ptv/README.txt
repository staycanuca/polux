->English<-

Peer-to-Peer TV (shorter p2ptv) is a free addon which lets you watch TV channels online anywhere in the world without restrictions using SopCast, AceStream, http, rtmp, rtsp and mmsh protocols.

The project has been abandoned, but the addon still works.
You can find all the dependencies here: https://gitlab.com/mariobalanica/p2ptv-dependencies/

Note: The author does NOT host any of the multimedia content you may watch using this addon.

plugin.video.p2ptv is distributed under GPLv3 license. 

->Română<-

Peer-to-Peer TV (abreviat p2ptv) este un addon gratuit ce vă permite să vizionați canale TV online oriunde în lume fără restricții utilizând protocoalele SopCast, AceStream, http, rtmp, rtsp și mmsh.

Proiectul a fost abandonat, însă addon-ul încă funcționează.
Puteți găsi toate dependințele acestuia aici: https://gitlab.com/mariobalanica/p2ptv-dependencies/

Notă: Autorul nu găzduiește conținutul multimedia vizionat cu ajutorul accestui addon!

plugin.video.p2ptv este distribuit sub licența GPLv3. 
