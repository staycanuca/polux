﻿# -*- coding: utf-8 -*-
import sqlite3
import xbmc


class DB(object):
    pass